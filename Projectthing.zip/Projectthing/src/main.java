import java.util.Arrays;
import java.util.Scanner;
public class main
{
	public static void main(String[] args) //Using this for tests for now
	{
		login();
	}
	public static void initializeStuArray(Student[]stuList) //loads the student array. this is a test class to print it but in the end it didnt matter to the overall product
	{
		int count = 0;
		int i = 0;
		//stuList[0] = new Student(700700000, "Joe", 3.5, 70, false); stuList[1] = new Student(700700001, "Lenny", 3.6, 75, false); stuList[2] = new Student(700700002, "Obi", 3.7, 80, true); stuList[3] = new Student(700700003, "Steven", 3.8, 85, false); idDatabase.writeFile(stuList);
		idDatabase.readFile(stuList);
		System.out.println(Arrays.toString(stuList));
	}
	public static void initializeApptArray(Appointment[]apptList) //same as initializeStuArray
	{
		int count = 0;
		int i = 0;
		apptDatabase.readFile(apptList);
		while(apptList[i] != null)
		{
				count++;
				System.out.println(count+". "+ apptList[i]);
				i++;
		}
	}
	public static void login() //decides whether the admin or a student/tutor is logging in
	{
		Scanner option = new Scanner(System.in);
		int choice = 0;
		while(choice != 1 || choice != 2)
		{
			Student[] stuList = new Student[200];
			Appointment[] apptList = new Appointment[200];
			idDatabase.readFile(stuList);
			apptDatabase.readFile(apptList);
			System.out.println("What are you?\n1. Student\n2. Admin");
			choice = option.nextInt();
			if(choice == 1)
			{
				int sid = 0;
				int i = 0;
				Student s;
				while(sid < 700700000 || sid > 700799999)
				{
					System.out.println("Enter student ID");
					sid = option.nextInt();
					while(stuList[i] != null)
					{
						int currentID = stuList[i].getID();
						if(sid == currentID)
						{
							s = stuList[i];
							s.load();
						}
						i++;
					}
				}
			}
			if(choice == 2)
			{
				Admin.load();
			}
		}
		
	}
}