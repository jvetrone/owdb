import java.util.Scanner;

public class Admin //Oversees the school system
{
	public static void load() //gives access to database functions
	{
		Scanner option = new Scanner(System.in);
		int choice = 0;
		while(choice != 5)
		{
			System.out.println("What would you like to do?\n1. Add Student\n2. Remove Student\n3. Accept Tutor\n4. Remove Tutor\n5. Exit");
			choice = option.nextInt();
			if(choice == 1)
				idDatabase.addStudent();
			if(choice == 2)
				idDatabase.removeStudent();
			if(choice == 3)
				idDatabase.acceptTutor();
			if(choice == 4)
				idDatabase.removeTutor();
		}
	}
}
